# Integration status

Status: **incomplete source snapshot**.

Missing modules required by the supplied files/tests: `canonical.py`, `crypto.py`, `models.py`, `access.py`, `control_plane.py`, `audit.py`, `gateway.py`, `workspace.py`, `governance.py`, `bootstrap.py`, and `cli.py`.

The `custos = "custos.cli:main"` entry point in `pyproject.toml` cannot resolve until `custos/cli.py` is provided. The integration tests were syntax-checked only; they were not executed because their dependencies are missing.

Security status: `security/red_team_round3_before_fix.txt` records unresolved findings. This file is a report of issues, not a fix or proof of mitigation.
