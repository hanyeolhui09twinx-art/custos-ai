# Custos AI v0.4 source snapshot — NOT YET RUNNABLE

This directory preserves the supplied v0.4 modules and tests in a conventional Python project layout. It is staged separately from the current root prototype because the supplied files do not form a complete package.

## Contents

- `custos/client.py`, `custos/mcp.py`, `custos/server.py`: supplied source files.
- `tests/test_e2e.py`, `tests/test_persistence.py`: supplied integration and persistence tests.
- `security/red_team_round3_before_fix.txt`: supplied round-3 finding summary.
- `pyproject.toml`: supplied project metadata and CLI entry point.

## Integration status

**Do not treat this snapshot as installable or production-ready.** The supplied code imports project modules that were not present in the uploaded archives: `custos.canonical`, `custos.crypto`, `custos.models`, `custos.access`, `custos.control_plane`, `custos.audit`, `custos.gateway`, `custos.workspace`, `custos.governance`, `custos.bootstrap`, and `custos.cli`. Because these modules are missing, the tests cannot run as a suite and the configured `custos` CLI entry point is unresolved. No missing implementation has been invented or represented as tested.

## Validation performed

- Python syntax parsing passed for the four supplied package files and `test_e2e.py`.
- Integration tests were **not** run: required modules are absent.
- The red-team report is explicitly a `before_fix` report. It lists findings that remain unresolved in this snapshot; do not interpret its presence as evidence that the vulnerabilities are fixed.

## Next step

Recover or generate the missing modules and align their interfaces with both test files. Then run the full suite in an isolated environment, fix failures, and repeat the adversarial checks before merging into the root prototype.
